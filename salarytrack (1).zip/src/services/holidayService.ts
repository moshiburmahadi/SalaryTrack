export interface Holiday {
  date: string;
  localName: string;
  name: string;
  countryCode: string;
  fixed: boolean;
  global: boolean;
  counties: string[] | null;
  launchYear: number | null;
  types: string[];
}

const CACHE_KEY = 'bd_holidays_cache';
const CACHE_EXPIRY = 24 * 60 * 60 * 1000; // 24 hours

export const fetchBangladeshHolidays = async (year: number): Promise<Holiday[]> => {
  const cacheKey = `${CACHE_KEY}_${year}`;
  const cachedData = localStorage.getItem(cacheKey);

  if (cachedData) {
    const { timestamp, data } = JSON.parse(cachedData);
    if (Date.now() - timestamp < CACHE_EXPIRY) {
      return data;
    }
  }

  try {
    const response = await fetch(`https://date.nager.at/api/v3/PublicHolidays/${year}/BD`);
    if (!response.ok) throw new Error('Failed to fetch holidays');
    const data = await response.json();
    
    localStorage.setItem(cacheKey, JSON.stringify({
      timestamp: Date.now(),
      data
    }));
    
    return data;
  } catch (error) {
    console.error('Error fetching holidays:', error);
    return [];
  }
};
